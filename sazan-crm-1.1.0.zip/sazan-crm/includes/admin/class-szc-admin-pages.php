<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** صفحه‌های ایمپورت، قالب‌های پیامک و تنظیمات. */
class SZC_Admin_Pages {

	public static function init() {
		add_action( 'admin_post_szc_import_upload',   array( __CLASS__, 'handle_import_upload' ) );
		add_action( 'admin_post_szc_import_run',      array( __CLASS__, 'handle_import_run' ) );
		add_action( 'admin_post_szc_template_save',   array( __CLASS__, 'handle_template_save' ) );
		add_action( 'admin_post_szc_template_delete', array( __CLASS__, 'handle_template_delete' ) );
		add_action( 'admin_post_szc_settings_save',   array( __CLASS__, 'handle_settings_save' ) );
		add_action( 'admin_post_szc_bulk',            array( __CLASS__, 'handle_bulk' ) );
		add_action( 'admin_post_szc_save_segment',    array( __CLASS__, 'handle_save_segment' ) );
		add_action( 'admin_post_szc_delete_segment',  array( __CLASS__, 'handle_delete_segment' ) );
		add_action( 'admin_post_szc_sequence_save',   array( __CLASS__, 'handle_sequence_save' ) );
		add_action( 'admin_post_szc_sequence_delete', array( __CLASS__, 'handle_sequence_delete' ) );
		add_action( 'admin_post_szc_blacklist_add',   array( __CLASS__, 'handle_blacklist_add' ) );
		add_action( 'admin_post_szc_blacklist_remove', array( __CLASS__, 'handle_blacklist_remove' ) );
		add_action( 'wp_ajax_szc_test_sms',           array( __CLASS__, 'ajax_test_sms' ) );
	}

	protected static function guard( $post = false ) {
		if ( ! SZC_Settings::can_access() ) {
			wp_die( 'دسترسی غیرمجاز' );
		}
	}

	protected static function url( $page, $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) );
	}

	protected static function delim_char( $key ) {
		$map = array( 'comma' => ',', 'semicolon' => ';', 'tab' => "\t" );
		return isset( $map[ $key ] ) ? $map[ $key ] : ',';
	}

	/* ==================== ایمپورت ==================== */

	public static function page_import() {
		self::guard();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$file  = isset( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
		$delim = isset( $_GET['delim'] ) ? sanitize_key( $_GET['delim'] ) : 'comma';
		// phpcs:enable
		$stats = get_transient( 'szc_import_' . get_current_user_id() );
		if ( $stats ) {
			delete_transient( 'szc_import_' . get_current_user_id() );
		}
		?>
		<div class="wrap szc-wrap">
			<h1>ایمپورت شماره‌ها</h1>

			<?php if ( $stats ) : ?>
				<div class="notice notice-success"><p>
					ایمپورت انجام شد —
					افزوده: <b><?php echo esc_html( szc_fa_digits( $stats['created'] ) ); ?></b>،
					به‌روزرسانی: <b><?php echo esc_html( szc_fa_digits( $stats['updated'] ) ); ?></b>،
					نامعتبر: <b><?php echo esc_html( szc_fa_digits( $stats['invalid'] ) ); ?></b>،
					کل ردیف: <b><?php echo esc_html( szc_fa_digits( $stats['total'] ) ); ?></b>.
					<?php if ( ! empty( $stats['capped'] ) ) : ?><br>توجه: به سقف <?php echo esc_html( szc_fa_digits( SZC_Import::MAX_ROWS ) ); ?> ردیف رسید؛ بقیه را در فایل جداگانه ایمپورت کنید.<?php endif; ?>
				</p></div>
				<p><a href="<?php echo esc_url( self::url( 'szc-contacts' ) ); ?>" class="button button-primary">مشاهده مخاطبین</a> <a href="<?php echo esc_url( self::url( 'szc-import' ) ); ?>" class="button">ایمپورت فایل دیگر</a></p>
				<?php return; endif; ?>

			<?php
			$preview = $file ? SZC_Import::preview( $file, self::delim_char( $delim ) ) : null;
			if ( $file && ( ! $preview || empty( $preview['ok'] ) ) ) :
				echo '<div class="notice notice-error"><p>' . esc_html( $preview['msg'] ?? 'خطا در خواندن فایل.' ) . '</p></div>';
				$file = '';
			endif;

			if ( ! $file ) : ?>
				<div class="szc-card" style="max-width:640px">
					<h2>گام ۱: بارگذاری فایل CSV</h2>
					<p class="szc-muted">فایل اکسل را با فرمت <b>CSV UTF-8</b> ذخیره کنید. ردیف اول می‌تواند سرستون باشد.</p>
					<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'szc_import_upload' ); ?>
						<input type="hidden" name="action" value="szc_import_upload">
						<p><input type="file" name="csv" accept=".csv,.txt" required></p>
						<p>
							<label>جداکننده:
								<select name="delim">
									<option value="comma">ویرگول (,)</option>
									<option value="semicolon">نقطه‌ویرگول (;)</option>
									<option value="tab">Tab</option>
								</select>
							</label>
						</p>
						<p><button class="button button-primary">بارگذاری و ادامه</button></p>
					</form>
				</div>
			<?php else :
				$header = $preview['header'];
				$sample = $preview['sample'];
				$fields = SZC_Import::fields();
				?>
				<div class="szc-card">
					<h2>گام ۲: نگاشت ستون‌ها</h2>
					<p class="szc-muted">مشخص کنید هر فیلد به کدام ستون فایل مربوط است. شماره‌های نامعتبر و تکراری خودکار حذف/ادغام می‌شوند.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'szc_import_run' ); ?>
						<input type="hidden" name="action" value="szc_import_run">
						<input type="hidden" name="file" value="<?php echo esc_attr( $file ); ?>">
						<input type="hidden" name="delim" value="<?php echo esc_attr( $delim ); ?>">

						<table class="form-table"><tbody>
						<?php foreach ( $fields as $fk => $flabel ) :
							$guess = self::guess_column( $fk, $header ); ?>
							<tr>
								<th><?php echo esc_html( $flabel ); ?></th>
								<td>
									<select name="map[<?php echo esc_attr( $fk ); ?>]">
										<option value="-1">— نادیده بگیر —</option>
										<?php foreach ( $header as $i => $h ) : ?>
											<option value="<?php echo (int) $i; ?>" <?php selected( $guess, $i ); ?>><?php echo esc_html( ( $h !== '' ? $h : 'ستون ' . ( $i + 1 ) ) ); ?></option>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody></table>

						<h3>پیش‌نمایش</h3>
						<div style="overflow:auto"><table class="widefat striped"><thead><tr>
							<?php foreach ( $header as $h ) : ?><th><?php echo esc_html( $h ); ?></th><?php endforeach; ?>
						</tr></thead><tbody>
							<?php foreach ( $sample as $r ) : ?>
								<tr><?php foreach ( $r as $cell ) : ?><td><?php echo esc_html( $cell ); ?></td><?php endforeach; ?></tr>
							<?php endforeach; ?>
						</tbody></table></div>

						<h3>تنظیمات ایمپورت</h3>
						<table class="form-table"><tbody>
							<tr><th>ردیف اول سرستون است؟</th><td><label><input type="checkbox" name="has_header" value="1" checked> بله، ردیف اول را نادیده بگیر</label></td></tr>
							<tr><th>منبع (برای همه)</th><td><input type="text" name="def_source" class="regular-text" placeholder="مثلاً: لیست نمایشگاه"></td></tr>
							<tr><th>برچسب (برای همه)</th><td><input type="text" name="def_tags" class="regular-text" placeholder="مثلاً: سرد-۱۴۰۵"></td></tr>
							<tr><th>اولویت پیش‌فرض</th><td>
								<select name="def_priority">
									<?php foreach ( SZC_Settings::priorities() as $k => $m ) : ?>
										<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $k, 'cold' ); ?>><?php echo esc_html( $m['label'] ); ?></option>
									<?php endforeach; ?>
								</select>
							</td></tr>
							<tr><th>مخاطبین موجود</th><td><label><input type="checkbox" name="update_existing" value="1" checked> فیلدهای خالیِ مخاطبین موجود با داده‌ی جدید پر شود</label></td></tr>
						</tbody></table>

						<p><button class="button button-primary">شروع ایمپورت</button></p>
					</form>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	protected static function guess_column( $field, $header ) {
		$keys = array(
			'mobile'     => array( 'mobile', 'phone', 'موبایل', 'همراه', 'تلفن', 'شماره' ),
			'first_name' => array( 'first', 'name', 'نام' ),
			'last_name'  => array( 'last', 'family', 'خانوادگی', 'فامیل' ),
			'job'        => array( 'job', 'شغل', 'occupation' ),
			'company'    => array( 'company', 'شرکت', 'سازمان' ),
			'city'       => array( 'city', 'شهر' ),
			'email'      => array( 'email', 'ایمیل', 'mail' ),
			'source'     => array( 'source', 'منبع' ),
			'tags'       => array( 'tag', 'برچسب' ),
		);
		$needles = $keys[ $field ] ?? array();
		foreach ( $header as $i => $h ) {
			$h = strtolower( trim( (string) $h ) ); // byte-level؛ برای فارسی هم درست کار می‌کند
			foreach ( $needles as $n ) {
				if ( $h !== '' && strpos( $h, strtolower( $n ) ) !== false ) {
					return $i;
				}
			}
		}
		return -1;
	}

	public static function handle_import_upload() {
		self::guard();
		check_admin_referer( 'szc_import_upload' );
		$delim = isset( $_POST['delim'] ) ? sanitize_key( $_POST['delim'] ) : 'comma';
		$res   = SZC_Import::store_upload( $_FILES['csv'] ?? array() );
		if ( empty( $res['ok'] ) ) {
			wp_die( esc_html( $res['msg'] ?? 'خطا در بارگذاری.' ) );
		}
		wp_safe_redirect( self::url( 'szc-import', array( 'file' => $res['file'], 'delim' => $delim ) ) );
		exit;
	}

	public static function handle_import_run() {
		self::guard();
		check_admin_referer( 'szc_import_run' );
		$file  = isset( $_POST['file'] ) ? sanitize_file_name( wp_unslash( $_POST['file'] ) ) : '';
		$delim = isset( $_POST['delim'] ) ? sanitize_key( $_POST['delim'] ) : 'comma';
		$map   = isset( $_POST['map'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['map'] ) ) : array();
		$res   = SZC_Import::run( $file, $map, array(
			'has_header'      => ! empty( $_POST['has_header'] ),
			'delimiter'       => self::delim_char( $delim ),
			'source'          => sanitize_text_field( wp_unslash( $_POST['def_source'] ?? '' ) ),
			'tags'            => sanitize_text_field( wp_unslash( $_POST['def_tags'] ?? '' ) ),
			'priority'        => sanitize_key( $_POST['def_priority'] ?? 'cold' ),
			'update_existing' => ! empty( $_POST['update_existing'] ),
		) );
		if ( empty( $res['ok'] ) ) {
			wp_die( esc_html( $res['msg'] ?? 'خطا در ایمپورت.' ) );
		}
		set_transient( 'szc_import_' . get_current_user_id(), $res['stats'], 60 );
		wp_safe_redirect( self::url( 'szc-import' ) );
		exit;
	}

	/* ==================== قالب‌های پیامک ==================== */

	public static function page_templates() {
		self::guard();
		$edit = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$row  = $edit ? SZC_Templates::get( $edit ) : null;
		$mode = SZC_Settings::get( 'sms_mode' );
		?>
		<div class="wrap szc-wrap">
			<h1>قالب‌های پیامک</h1>
			<?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-success is-dismissible"><p>ذخیره شد.</p></div><?php endif; ?>

			<div class="szc-single-grid">
				<div class="szc-col">
					<div class="szc-card">
						<h2><?php echo $row ? 'ویرایش قالب' : 'قالب جدید'; ?></h2>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<?php wp_nonce_field( 'szc_template_save' ); ?>
							<input type="hidden" name="action" value="szc_template_save">
							<input type="hidden" name="id" value="<?php echo (int) ( $row->id ?? 0 ); ?>">
							<p><label>نام قالب<br><input type="text" name="name" class="regular-text" required value="<?php echo esc_attr( $row->name ?? '' ); ?>"></label></p>
							<p><label>متن پیامک<br><textarea name="body" rows="4" class="large-text" required><?php echo esc_textarea( $row->body ?? '' ); ?></textarea></label></p>
							<p class="szc-muted">متغیرها: <code>%first%</code> نام، <code>%name%</code> نام کامل، <code>%company%</code> شرکت، <code>%job%</code> شغل، <code>%city%</code> شهر، <code>%mini%</code> لینک مینی‌دوره، <code>%intro%</code> لینک معارفه.</p>
							<?php if ( $mode === 'pattern' ) : ?>
								<p><label>کد پترن (اختیاری، برای خط خدماتی)<br><input type="text" name="pattern_code" dir="ltr" class="regular-text" value="<?php echo esc_attr( $row->pattern_code ?? '' ); ?>"></label>
								<br><span class="szc-muted">در حالت پترن، مقادیر با نام متغیرهای بالا ارسال می‌شوند.</span></p>
							<?php endif; ?>
							<p><button class="button button-primary"><?php echo $row ? 'ذخیره تغییرات' : 'ایجاد قالب'; ?></button>
								<?php if ( $row ) : ?><a class="button" href="<?php echo esc_url( self::url( 'szc-templates' ) ); ?>">قالب جدید</a><?php endif; ?></p>
						</form>
					</div>
				</div>
				<div class="szc-col">
					<div class="szc-card">
						<h2>قالب‌های موجود</h2>
						<?php $all = SZC_Templates::all(); if ( ! $all ) : ?>
							<p class="szc-muted">هنوز قالبی نساخته‌اید.</p>
						<?php else : ?>
							<ul class="szc-tpl-list">
								<?php foreach ( $all as $t ) : ?>
									<li>
										<div><b><?php echo esc_html( $t->name ); ?></b><p class="szc-muted"><?php echo esc_html( wp_trim_words( $t->body, 20 ) ); ?></p></div>
										<div class="szc-tpl-ops">
											<a class="button-link" href="<?php echo esc_url( self::url( 'szc-templates', array( 'edit' => $t->id ) ) ); ?>">ویرایش</a>
											<a class="button-link szc-danger" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=szc_template_delete&id=' . $t->id ), 'szc_template_delete_' . $t->id ) ); ?>" onclick="return confirm('این قالب حذف شود؟')">حذف</a>
										</div>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public static function handle_template_save() {
		self::guard();
		check_admin_referer( 'szc_template_save' );
		$id   = absint( $_POST['id'] ?? 0 );
		$name = wp_unslash( $_POST['name'] ?? '' );
		$body = wp_unslash( $_POST['body'] ?? '' );
		$pat  = wp_unslash( $_POST['pattern_code'] ?? '' );
		if ( $id ) {
			SZC_Templates::update( $id, $name, $body, $pat );
		} else {
			SZC_Templates::create( $name, $body, $pat );
		}
		wp_safe_redirect( self::url( 'szc-templates', array( 'msg' => 1 ) ) );
		exit;
	}

	public static function handle_template_delete() {
		self::guard();
		$id = absint( $_GET['id'] ?? 0 );
		check_admin_referer( 'szc_template_delete_' . $id );
		SZC_Templates::delete( $id );
		wp_safe_redirect( self::url( 'szc-templates' ) );
		exit;
	}

	/* ==================== تنظیمات ==================== */

	public static function page_settings() {
		self::guard();
		$s         = SZC_Settings::all();
		$templates = SZC_Templates::all();
		$staff     = get_users( array( 'role__in' => array( 'administrator', 'editor', 'author', 'shop_manager', 'contributor' ), 'number' => 500, 'fields' => array( 'ID', 'display_name', 'user_login' ) ) );
		$managers  = SZC_Settings::manager_ids();
		$agents    = SZC_Settings::agent_ids();
		?>
		<div class="wrap szc-wrap">
			<h1>تنظیمات سازان CRM</h1>
			<?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-success is-dismissible"><p>تنظیمات ذخیره شد.</p></div><?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'szc_settings_save' ); ?>
				<input type="hidden" name="action" value="szc_settings_save">

				<h2>دسترسی و نقش‌ها</h2>
				<table class="form-table"><tbody>
					<tr><th>مدیران فروش</th><td>
						<select name="managers[]" multiple size="6" style="min-width:320px">
							<?php foreach ( $staff as $u ) : ?>
								<option value="<?php echo (int) $u->ID; ?>" <?php echo in_array( (int) $u->ID, $managers, true ) ? 'selected' : ''; ?>><?php echo esc_html( $u->display_name . ' (' . $u->user_login . ')' ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">مدیر همه‌ی سرنخ‌ها را می‌بیند و می‌تواند تخصیص دهد. (مدیران سایت همیشه مدیر فروش‌اند.)</p>
					</td></tr>
					<tr><th>کارشناسان فروش</th><td>
						<select name="agents[]" multiple size="6" style="min-width:320px">
							<?php foreach ( $staff as $u ) : ?>
								<option value="<?php echo (int) $u->ID; ?>" <?php echo in_array( (int) $u->ID, $agents, true ) ? 'selected' : ''; ?>><?php echo esc_html( $u->display_name . ' (' . $u->user_login . ')' ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">کارشناس فقط سرنخ‌های تخصیص‌یافته به خودش را می‌بیند. (Ctrl/Cmd برای انتخاب چندتایی)</p>
					</td></tr>
				</tbody></table>

				<h2>پنل پیامک (فراز/آی‌پی‌پنل)</h2>
				<table class="form-table"><tbody>
					<tr><th>فعال‌سازی</th><td><label><input type="checkbox" name="sms_enabled" value="1" <?php checked( ! empty( $s['sms_enabled'] ) ); ?>> ارسال پیامک فعال باشد</label></td></tr>
					<tr><th>آدرس پایه API</th><td><input type="text" name="sms_base" value="<?php echo esc_attr( $s['sms_base'] ); ?>" class="regular-text" dir="ltr"></td></tr>
					<tr><th>کلید API</th><td><input type="text" name="sms_apikey" value="<?php echo esc_attr( $s['sms_apikey'] ); ?>" class="regular-text" dir="ltr" autocomplete="off"></td></tr>
					<tr><th>خط ارسال</th><td><input type="text" name="sms_originator" value="<?php echo esc_attr( $s['sms_originator'] ); ?>" class="regular-text" dir="ltr" placeholder="+983000..."></td></tr>
					<tr><th>حالت ارسال</th><td>
						<select name="sms_mode">
							<option value="text" <?php selected( $s['sms_mode'], 'text' ); ?>>متن آزاد</option>
							<option value="pattern" <?php selected( $s['sms_mode'], 'pattern' ); ?>>پترن (خدماتی)</option>
						</select>
						<p class="description">اگر تنظیمات پیامک را در «سازان پنل» دارید، همان مقادیر این‌جا هم پیش‌فرض آمده است.</p>
					</td></tr>
					<tr><th>بازه‌ی مجاز ارسال</th><td>
						از ساعت <input type="number" name="send_from" min="0" max="23" value="<?php echo esc_attr( $s['send_from'] ); ?>" class="small-text">
						تا ساعت <input type="number" name="send_to" min="1" max="24" value="<?php echo esc_attr( $s['send_to'] ); ?>" class="small-text">
						<p class="description">پیامک‌های خودکار فقط در این بازه ارسال می‌شوند (برای پرهیز از پیامک شبانه).</p>
					</td></tr>
					<tr><th>سقف ارسال در هر نوبت</th><td>
						<input type="number" name="max_per_run" min="1" value="<?php echo esc_attr( $s['max_per_run'] ); ?>" class="small-text"> پیامک در هر اجرای صف (هر ۵ دقیقه)
						<p class="description">برای محدودسازی نرخ ارسال انبوه و پرهیز از فشار روی خط پیامک.</p>
					</td></tr>
					<tr><th>سقف ارسال روزانه</th><td>
						<input type="number" name="max_per_day" min="0" value="<?php echo esc_attr( $s['max_per_day'] ); ?>" class="small-text"> (۰ = نامحدود)
					</td></tr>
				</tbody></table>

				<h2>اتوماسیون پس از تماس</h2>
				<table class="form-table"><tbody>
					<tr><th>فعال باشد</th><td><label><input type="checkbox" name="auto_after_call" value="1" <?php checked( ! empty( $s['auto_after_call'] ) ); ?>> پس از ثبت تماسِ موفق، پیامک تشکر/دعوت زمان‌بندی شود</label></td></tr>
					<tr><th>قالب پیش‌فرض</th><td>
						<select name="auto_template_id">
							<option value="0">— اولین قالب —</option>
							<?php foreach ( $templates as $t ) : ?>
								<option value="<?php echo (int) $t->id; ?>" <?php selected( (int) $s['auto_template_id'], (int) $t->id ); ?>><?php echo esc_html( $t->name ); ?></option>
							<?php endforeach; ?>
						</select>
					</td></tr>
					<tr><th>فاصله‌ی ارسال</th><td><input type="number" name="auto_delay_min" min="1" value="<?php echo esc_attr( $s['auto_delay_min'] ); ?>" class="small-text"> دقیقه پس از تماس (پیش‌فرض ۶۰)</td></tr>
					<tr><th>لینک مینی‌دوره</th><td><input type="url" name="mini_link" value="<?php echo esc_attr( $s['mini_link'] ); ?>" class="regular-text" dir="ltr"> <span class="szc-muted">متغیر <code>%mini%</code></span></td></tr>
					<tr><th>لینک جلسه‌ی معارفه</th><td><input type="url" name="intro_link" value="<?php echo esc_attr( $s['intro_link'] ); ?>" class="regular-text" dir="ltr"> <span class="szc-muted">متغیر <code>%intro%</code></span></td></tr>
				</tbody></table>

				<p><button class="button button-primary">ذخیره تنظیمات</button></p>
			</form>

			<hr>
			<h2>تست پیامک</h2>
			<p>
				<input type="text" id="szc-test-num" class="regular-text" dir="ltr" placeholder="۰۹۱۲...">
				<button type="button" class="button" id="szc-test-sms" data-nonce="<?php echo esc_attr( wp_create_nonce( 'szc_admin' ) ); ?>">ارسال پیامک تست</button>
				<span id="szc-test-msg" style="margin-inline-start:8px;font-weight:600"></span>
			</p>
		</div>
		<?php
	}

	public static function handle_settings_save() {
		self::guard();
		check_admin_referer( 'szc_settings_save' );
		$p   = wp_unslash( $_POST );
		$new = array(
			'managers'         => array_map( 'intval', (array) ( $p['managers'] ?? array() ) ),
			'agents'           => array_map( 'intval', (array) ( $p['agents'] ?? array() ) ),
			'max_per_run'      => max( 1, absint( $p['max_per_run'] ?? 80 ) ),
			'max_per_day'      => max( 0, absint( $p['max_per_day'] ?? 0 ) ),
			'sms_enabled'      => empty( $p['sms_enabled'] ) ? 0 : 1,
			'sms_base'         => esc_url_raw( $p['sms_base'] ?? '' ),
			'sms_apikey'       => sanitize_text_field( $p['sms_apikey'] ?? '' ),
			'sms_originator'   => sanitize_text_field( $p['sms_originator'] ?? '' ),
			'sms_mode'         => ( ( $p['sms_mode'] ?? 'text' ) === 'pattern' ) ? 'pattern' : 'text',
			'send_from'        => min( 23, max( 0, absint( $p['send_from'] ?? 9 ) ) ),
			'send_to'          => min( 24, max( 1, absint( $p['send_to'] ?? 21 ) ) ),
			'auto_after_call'  => empty( $p['auto_after_call'] ) ? 0 : 1,
			'auto_template_id' => absint( $p['auto_template_id'] ?? 0 ),
			'auto_delay_min'   => max( 1, absint( $p['auto_delay_min'] ?? 60 ) ),
			'mini_link'        => esc_url_raw( $p['mini_link'] ?? '' ),
			'intro_link'       => esc_url_raw( $p['intro_link'] ?? '' ),
		);
		SZC_Settings::save( $new );
		wp_safe_redirect( self::url( 'szc-settings', array( 'msg' => 1 ) ) );
		exit;
	}

	public static function ajax_test_sms() {
		if ( ! SZC_Settings::can_access() ) {
			wp_send_json_error( array( 'msg' => 'دسترسی غیرمجاز' ), 403 );
		}
		check_ajax_referer( 'szc_admin', 'nonce' );
		if ( ! SZC_SMS::enabled() ) {
			wp_send_json_error( array( 'msg' => 'سرویس پیامک فعال نیست یا کلید/خط خالی است. ابتدا ذخیره کنید.' ) );
		}
		$to = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : '';
		if ( ! szc_is_valid_mobile( szc_normalize_mobile( $to ) ) ) {
			wp_send_json_error( array( 'msg' => 'شماره موبایل معتبر وارد کنید.' ) );
		}
		$res = SZC_SMS::send_text( $to, 'پیامک آزمایشی سازان CRM ✓' );
		if ( ! empty( $res['ok'] ) ) {
			wp_send_json_success( array( 'msg' => 'ارسال شد ✓' ) );
		}
		wp_send_json_error( array( 'msg' => $res['msg'] ?? 'ارسال ناموفق بود.' ) );
	}

	/* ==================== اقدام گروهی ==================== */

	public static function handle_bulk() {
		self::guard();
		check_admin_referer( 'szc_bulk' );
		$is_manager = SZC_Settings::is_manager();
		$scope      = ( ( $_POST['scope'] ?? '' ) === 'all' ) ? 'all' : 'selected';
		$action     = sanitize_key( $_POST['bulk_action'] ?? '' );

		$fargs = array(
			'search'   => sanitize_text_field( wp_unslash( $_POST['f_s'] ?? '' ) ),
			'stage'    => sanitize_key( $_POST['f_stage'] ?? '' ),
			'priority' => sanitize_key( $_POST['f_priority'] ?? '' ),
			'due'      => sanitize_key( $_POST['f_due'] ?? '' ),
			'owner'    => absint( $_POST['f_owner'] ?? 0 ),
		);
		if ( ! $is_manager ) {
			$fargs['owner'] = get_current_user_id();
		}

		if ( $scope === 'all' ) {
			$ids = SZC_Contacts::ids_matching( $fargs );
		} else {
			$ids = array_map( 'intval', (array) ( $_POST['ids'] ?? array() ) );
			if ( ! $is_manager ) {
				$self = get_current_user_id();
				$ids  = array_values( array_filter( $ids, function ( $id ) use ( $self ) {
					$c = SZC_Contacts::get( $id );
					return $c && (int) $c->owner_id === $self;
				} ) );
			}
		}
		$ids = array_values( array_filter( $ids ) );
		$n   = count( $ids );
		$msg = '';

		switch ( $action ) {
			case 'stage':
				$v = sanitize_key( $_POST['p_stage'] ?? '' );
				foreach ( $ids as $id ) { SZC_Contacts::set_stage( $id, $v ); }
				$msg = 'مرحله‌ی ' . szc_fa_digits( $n ) . ' مخاطب تغییر کرد.';
				break;
			case 'priority':
				$v = sanitize_key( $_POST['p_priority'] ?? '' );
				foreach ( $ids as $id ) { SZC_Contacts::set_priority( $id, $v ); }
				$msg = 'اولویت ' . szc_fa_digits( $n ) . ' مخاطب تغییر کرد.';
				break;
			case 'tag':
				$tag = sanitize_text_field( wp_unslash( $_POST['p_tag'] ?? '' ) );
				foreach ( $ids as $id ) { SZC_Contacts::add_tag( $id, $tag ); }
				$msg = 'برچسب به ' . szc_fa_digits( $n ) . ' مخاطب افزوده شد.';
				break;
			case 'assign':
				if ( $is_manager ) {
					$owner = absint( $_POST['p_owner'] ?? 0 );
					foreach ( $ids as $id ) { SZC_Contacts::set_owner( $id, $owner ); }
					$msg = szc_fa_digits( $n ) . ' مخاطب تخصیص یافت.';
				}
				break;
			case 'blacklist':
				foreach ( $ids as $id ) {
					$c = SZC_Contacts::get( $id );
					if ( $c ) { SZC_Blacklist::add( $c->mobile, 'اقدام گروهی' ); }
				}
				$msg = szc_fa_digits( $n ) . ' مخاطب به لیست سیاه رفت.';
				break;
			case 'delete':
				foreach ( $ids as $id ) { SZC_Contacts::delete( $id ); }
				$msg = szc_fa_digits( $n ) . ' مخاطب حذف شد.';
				break;
			case 'send':
				$tid = absint( $_POST['p_template'] ?? 0 );
				$r   = SZC_SMS::enqueue_template_bulk( $ids, $tid );
				$msg = szc_fa_digits( $r['queued'] ) . ' پیامک در صف قرار گرفت (' . szc_fa_digits( $r['skipped'] ) . ' رد شد).';
				break;
			case 'enroll':
				$sid = absint( $_POST['p_sequence'] ?? 0 );
				$r   = SZC_Sequences::enroll_bulk( $sid, $ids );
				$msg = szc_fa_digits( $r['enrolled'] ) . ' مخاطب در دنباله ثبت شد (' . szc_fa_digits( $r['skipped'] ) . ' رد شد).';
				break;
			default:
				$msg = 'اقدامی انتخاب نشد.';
		}
		set_transient( 'szc_bulk_' . get_current_user_id(), $msg, 60 );
		wp_safe_redirect( wp_get_referer() ?: self::url( 'szc-contacts' ) );
		exit;
	}

	/* ==================== بخش‌بندی ==================== */

	public static function handle_save_segment() {
		self::guard();
		check_admin_referer( 'szc_save_segment' );
		$name = sanitize_text_field( wp_unslash( $_POST['seg_name'] ?? '' ) );
		if ( $name !== '' ) {
			SZC_Segments::create( $name, array(
				'search'   => sanitize_text_field( wp_unslash( $_POST['f_s'] ?? '' ) ),
				'stage'    => sanitize_key( $_POST['f_stage'] ?? '' ),
				'priority' => sanitize_key( $_POST['f_priority'] ?? '' ),
				'due'      => sanitize_key( $_POST['f_due'] ?? '' ),
				'owner'    => absint( $_POST['f_owner'] ?? 0 ),
			) );
		}
		wp_safe_redirect( wp_get_referer() ?: self::url( 'szc-contacts' ) );
		exit;
	}

	public static function handle_delete_segment() {
		self::guard();
		$id = absint( $_GET['id'] ?? 0 );
		check_admin_referer( 'szc_delete_segment_' . $id );
		SZC_Segments::delete( $id );
		wp_safe_redirect( self::url( 'szc-segments' ) );
		exit;
	}

	public static function page_segments() {
		self::guard();
		$segments = SZC_Segments::all();
		?>
		<div class="wrap szc-wrap">
			<h1>بخش‌بندی‌ها (فیلترهای ذخیره‌شده)</h1>
			<p class="szc-muted">در صفحه‌ی «مخاطبین» فیلتر بزنید و با دکمه‌ی «ذخیره بخش‌بندی» آن را این‌جا نگه دارید.</p>
			<table class="wp-list-table widefat fixed striped">
				<thead><tr><th>نام</th><th>فیلترها</th><th></th></tr></thead>
				<tbody>
				<?php if ( ! $segments ) : ?>
					<tr><td colspan="3" class="szc-muted">هنوز بخش‌بندی‌ای ذخیره نشده است.</td></tr>
				<?php else : foreach ( $segments as $sg ) :
					$f = SZC_Segments::filters( $sg ); ?>
					<tr>
						<td><a href="<?php echo esc_url( self::url( 'szc-contacts', $f ) ); ?>"><b><?php echo esc_html( $sg->name ); ?></b></a></td>
						<td class="szc-muted"><?php echo esc_html( implode( '، ', array_map( function ( $k, $v ) { return $k . '=' . $v; }, array_keys( $f ), $f ) ) ?: '—' ); ?></td>
						<td><a class="button-link szc-danger" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=szc_delete_segment&id=' . $sg->id ), 'szc_delete_segment_' . $sg->id ) ); ?>" onclick="return confirm('حذف شود؟')">حذف</a></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* ==================== پیگیری‌ها ==================== */

	public static function page_followups() {
		self::guard();
		$tab   = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'due'; // phpcs:ignore WordPress.Security.NonceVerification
		$owner = SZC_Settings::scope_owner();
		$rows  = SZC_Activity::followups( $tab === 'upcoming' ? 'upcoming' : 'due', $owner, 300 );
		?>
		<div class="wrap szc-wrap">
			<h1>پیگیری‌ها</h1>
			<div class="szc-msg" aria-live="polite"></div>
			<h2 class="nav-tab-wrapper">
				<a class="nav-tab <?php echo $tab === 'due' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( self::url( 'szc-followups', array( 'tab' => 'due' ) ) ); ?>">امروز و عقب‌افتاده</a>
				<a class="nav-tab <?php echo $tab === 'upcoming' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( self::url( 'szc-followups', array( 'tab' => 'upcoming' ) ) ); ?>">آینده</a>
			</h2>
			<table class="wp-list-table widefat fixed striped" style="margin-top:12px">
				<thead><tr><th>مخاطب</th><th>موبایل</th><th>زمان</th><th>موضوع</th><th></th></tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="5" class="szc-muted">موردی نیست.</td></tr>
				<?php else : foreach ( $rows as $r ) :
					$overdue = ( $tab === 'due' && strtotime( $r->due_at ) < strtotime( current_time( 'mysql' ) ) - DAY_IN_SECONDS ); ?>
					<tr>
						<td><a href="<?php echo esc_url( add_query_arg( array( 'page' => 'szc-contacts', 'contact' => $r->contact_id ), admin_url( 'admin.php' ) ) ); ?>"><b><?php echo esc_html( trim( $r->first_name . ' ' . $r->last_name ) ?: szc_fa_digits( $r->mobile ) ); ?></b></a></td>
						<td dir="ltr"><?php echo esc_html( szc_fa_digits( $r->mobile ) ); ?></td>
						<td class="<?php echo $overdue ? 'szc-danger' : ''; ?>"><?php echo esc_html( szc_format_mysql( $r->due_at ) ); ?></td>
						<td class="szc-muted"><?php echo esc_html( $r->body ?: '—' ); ?></td>
						<td><button class="button button-small" data-szc-act="done_followup" data-id="<?php echo (int) $r->id; ?>">انجام شد</button></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* ==================== دنباله‌های پیامکی ==================== */

	public static function page_sequences() {
		self::guard();
		$edit      = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$seq       = $edit ? SZC_Sequences::get( $edit ) : null;
		$steps     = $seq ? SZC_Sequences::steps( $seq->id ) : array();
		$templates = SZC_Templates::all();
		?>
		<div class="wrap szc-wrap">
			<h1>دنباله‌های پیامکی (Drip)</h1>
			<?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-success is-dismissible"><p>ذخیره شد.</p></div><?php endif; ?>
			<?php if ( ! $templates ) : ?>
				<div class="notice notice-warning"><p>ابتدا از <a href="<?php echo esc_url( self::url( 'szc-templates' ) ); ?>">قالب‌های پیامک</a> چند قالب بسازید تا بتوانید گام‌های دنباله را تعریف کنید.</p></div>
			<?php endif; ?>

			<div class="szc-single-grid">
				<div class="szc-col">
					<div class="szc-card">
						<h2><?php echo $seq ? 'ویرایش دنباله' : 'دنباله‌ی جدید'; ?></h2>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<?php wp_nonce_field( 'szc_sequence_save' ); ?>
							<input type="hidden" name="action" value="szc_sequence_save">
							<input type="hidden" name="id" value="<?php echo (int) ( $seq->id ?? 0 ); ?>">
							<p><label>نام دنباله<br><input type="text" name="name" class="regular-text" required value="<?php echo esc_attr( $seq->name ?? '' ); ?>"></label></p>
							<p><label><input type="checkbox" name="active" value="1" <?php checked( $seq ? $seq->active : 1 ); ?>> فعال</label></p>
							<h3>گام‌ها</h3>
							<p class="szc-muted">هر گام: چند روز پس از ثبت‌نام، ساعت چند، با کدام قالب. قالبِ «— بدون —» یعنی آن ردیف نادیده گرفته می‌شود.</p>
							<table class="widefat"><thead><tr><th>روز</th><th>ساعت</th><th>قالب</th></tr></thead><tbody>
							<?php for ( $i = 0; $i < 6; $i++ ) :
								$st = $steps[ $i ] ?? null; ?>
								<tr>
									<td><input type="number" name="step_day[]" min="0" value="<?php echo esc_attr( $st ? $st->day_offset : ( $i === 0 ? 0 : '' ) ); ?>" class="small-text"></td>
									<td><input type="number" name="step_hour[]" min="0" max="23" value="<?php echo esc_attr( $st ? $st->hour : 10 ); ?>" class="small-text"></td>
									<td>
										<select name="step_template[]">
											<option value="0">— بدون —</option>
											<?php foreach ( $templates as $t ) : ?>
												<option value="<?php echo (int) $t->id; ?>" <?php selected( $st ? (int) $st->template_id : 0, (int) $t->id ); ?>><?php echo esc_html( $t->name ); ?></option>
											<?php endforeach; ?>
										</select>
									</td>
								</tr>
							<?php endfor; ?>
							</tbody></table>
							<p style="margin-top:12px"><button class="button button-primary"><?php echo $seq ? 'ذخیره' : 'ایجاد دنباله'; ?></button>
								<?php if ( $seq ) : ?><a class="button" href="<?php echo esc_url( self::url( 'szc-sequences' ) ); ?>">دنباله‌ی جدید</a><?php endif; ?></p>
						</form>
					</div>
				</div>
				<div class="szc-col">
					<div class="szc-card">
						<h2>دنباله‌های موجود</h2>
						<?php $all = SZC_Sequences::all(); if ( ! $all ) : ?>
							<p class="szc-muted">هنوز دنباله‌ای نساخته‌اید.</p>
						<?php else : ?>
							<ul class="szc-tpl-list">
								<?php foreach ( $all as $s ) : $stt = SZC_Sequences::stats( $s->id ); ?>
									<li>
										<div><b><?php echo esc_html( $s->name ); ?></b> <?php echo $s->active ? '' : '<span class="szc-muted">(غیرفعال)</span>'; ?>
											<p class="szc-muted"><?php echo esc_html( szc_fa_digits( $stt['steps'] ) ); ?> گام · <?php echo esc_html( szc_fa_digits( $stt['active'] ) ); ?> ثبت‌نام فعال</p></div>
										<div class="szc-tpl-ops">
											<a class="button-link" href="<?php echo esc_url( self::url( 'szc-sequences', array( 'edit' => $s->id ) ) ); ?>">ویرایش</a>
											<a class="button-link szc-danger" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=szc_sequence_delete&id=' . $s->id ), 'szc_sequence_delete_' . $s->id ) ); ?>" onclick="return confirm('حذف دنباله و لغو گام‌های در صف؟')">حذف</a>
										</div>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public static function handle_sequence_save() {
		self::guard();
		check_admin_referer( 'szc_sequence_save' );
		$id     = absint( $_POST['id'] ?? 0 );
		$name   = wp_unslash( $_POST['name'] ?? '' );
		$active = ! empty( $_POST['active'] );
		if ( $id ) {
			SZC_Sequences::update( $id, $name, $active );
		} else {
			$id = SZC_Sequences::create( $name );
			if ( ! $active ) { SZC_Sequences::update( $id, $name, false ); }
		}
		$days = array_map( 'intval', (array) ( $_POST['step_day'] ?? array() ) );
		$hrs  = array_map( 'intval', (array) ( $_POST['step_hour'] ?? array() ) );
		$tpls = array_map( 'intval', (array) ( $_POST['step_template'] ?? array() ) );
		$rows = array();
		foreach ( $tpls as $i => $tid ) {
			if ( $tid > 0 ) {
				$rows[] = array( 'day_offset' => $days[ $i ] ?? 0, 'hour' => $hrs[ $i ] ?? 10, 'template_id' => $tid );
			}
		}
		if ( $id ) {
			SZC_Sequences::set_steps( $id, $rows );
		}
		wp_safe_redirect( self::url( 'szc-sequences', array( 'edit' => $id, 'msg' => 1 ) ) );
		exit;
	}

	public static function handle_sequence_delete() {
		self::guard();
		$id = absint( $_GET['id'] ?? 0 );
		check_admin_referer( 'szc_sequence_delete_' . $id );
		SZC_Sequences::delete( $id );
		wp_safe_redirect( self::url( 'szc-sequences' ) );
		exit;
	}

	/* ==================== لیست سیاه ==================== */

	public static function page_blacklist() {
		self::guard();
		$page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$rows = SZC_Blacklist::all( 100, $page );
		$cnt  = SZC_Blacklist::count();
		?>
		<div class="wrap szc-wrap">
			<h1>لیست سیاه (لغو دریافت سراسری)</h1>
			<p class="szc-muted">شماره‌های این فهرست هرگز پیامک دریافت نمی‌کنند (چه دستی، چه خودکار، چه دنباله). مجموع: <b><?php echo esc_html( szc_fa_digits( $cnt ) ); ?></b></p>

			<div class="szc-card" style="max-width:640px">
				<h2>افزودن شماره</h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'szc_blacklist_add' ); ?>
					<input type="hidden" name="action" value="szc_blacklist_add">
					<p><textarea name="numbers" rows="4" class="large-text" dir="ltr" placeholder="هر خط یک شماره (۰۹...)"></textarea></p>
					<p><input type="text" name="reason" class="regular-text" placeholder="دلیل (اختیاری)"></p>
					<p><button class="button button-primary">افزودن به لیست سیاه</button></p>
				</form>
			</div>

			<table class="wp-list-table widefat fixed striped" style="margin-top:16px">
				<thead><tr><th>موبایل</th><th>دلیل</th><th>تاریخ</th><th></th></tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="4" class="szc-muted">فهرست خالی است.</td></tr>
				<?php else : foreach ( $rows as $r ) : ?>
					<tr>
						<td dir="ltr"><?php echo esc_html( szc_fa_digits( $r->mobile ) ); ?></td>
						<td class="szc-muted"><?php echo esc_html( $r->reason ?: '—' ); ?></td>
						<td class="szc-muted"><?php echo esc_html( szc_format_mysql( $r->created_at, false ) ); ?></td>
						<td><a class="button-link szc-danger" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=szc_blacklist_remove&id=' . $r->id ), 'szc_blacklist_remove_' . $r->id ) ); ?>">حذف</a></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function handle_blacklist_add() {
		self::guard();
		check_admin_referer( 'szc_blacklist_add' );
		$n = SZC_Blacklist::add_bulk_text( wp_unslash( $_POST['numbers'] ?? '' ), sanitize_text_field( wp_unslash( $_POST['reason'] ?? '' ) ) );
		set_transient( 'szc_bulk_' . get_current_user_id(), szc_fa_digits( $n ) . ' شماره به لیست سیاه افزوده شد.', 60 );
		wp_safe_redirect( self::url( 'szc-blacklist' ) );
		exit;
	}

	public static function handle_blacklist_remove() {
		self::guard();
		$id = absint( $_GET['id'] ?? 0 );
		check_admin_referer( 'szc_blacklist_remove_' . $id );
		SZC_Blacklist::remove( $id );
		wp_safe_redirect( self::url( 'szc-blacklist' ) );
		exit;
	}

	/* ==================== گزارش‌ها ==================== */

	public static function page_reports() {
		self::guard();
		$owner   = SZC_Settings::scope_owner();
		$funnel  = SZC_Reports::funnel( $owner );
		$byout   = SZC_Reports::calls_by_outcome( 7 );
		$board   = SZC_Settings::is_manager() ? SZC_Reports::agent_leaderboard() : array();
		$maxstage = 1;
		foreach ( $funnel['stages'] as $s ) { $maxstage = max( $maxstage, $s['count'] ); }
		?>
		<div class="wrap szc-wrap">
			<h1>گزارش‌ها</h1>

			<div class="szc-kpis">
				<div class="szc-kpi"><span class="szc-kpi-n"><?php echo esc_html( szc_fa_digits( SZC_Reports::calls_today( $owner ) ) ); ?></span><span class="szc-kpi-l">تماس امروز</span></div>
				<div class="szc-kpi"><span class="szc-kpi-n"><?php echo esc_html( szc_fa_digits( SZC_Reports::sms_sent( 1 ) ) ); ?></span><span class="szc-kpi-l">پیامک امروز</span></div>
				<div class="szc-kpi"><span class="szc-kpi-n"><?php echo esc_html( szc_fa_digits( SZC_Reports::sms_sent( 7 ) ) ); ?></span><span class="szc-kpi-l">پیامک ۷ روز</span></div>
				<div class="szc-kpi"><span class="szc-kpi-n"><?php echo esc_html( szc_fa_digits( $funnel['conversion'] ) ); ?>٪</span><span class="szc-kpi-l">نرخ تبدیل</span></div>
			</div>

			<div class="szc-single-grid">
				<div class="szc-col">
					<div class="szc-card">
						<h2>قیف فروش</h2>
						<div class="szc-funnel">
							<?php foreach ( $funnel['stages'] as $s ) :
								$w = $maxstage > 0 ? round( $s['count'] / $maxstage * 100 ) : 0; ?>
								<div class="szc-funnel-row">
									<span class="szc-funnel-lbl"><?php echo esc_html( $s['label'] ); ?></span>
									<span class="szc-funnel-bar"><span style="width:<?php echo (int) $w; ?>%"></span></span>
									<span class="szc-funnel-n"><?php echo esc_html( szc_fa_digits( $s['count'] ) ); ?></span>
								</div>
							<?php endforeach; ?>
						</div>
						<p class="szc-muted">مجموع: <?php echo esc_html( szc_fa_digits( $funnel['total'] ) ); ?> · ثبت‌نام: <?php echo esc_html( szc_fa_digits( $funnel['registered'] ) ); ?></p>
					</div>
				</div>
				<div class="szc-col">
					<div class="szc-card">
						<h2>تماس‌های ۷ روز اخیر (بر اساس نتیجه)</h2>
						<ul class="szc-queue-stats">
							<?php foreach ( $byout as $o ) : ?>
								<li><?php echo esc_html( $o['label'] ); ?>: <b><?php echo esc_html( szc_fa_digits( $o['count'] ) ); ?></b></li>
							<?php endforeach; ?>
						</ul>
					</div>
					<?php if ( $board ) : ?>
					<div class="szc-card">
						<h2>عملکرد کارشناسان (تماسِ امروز)</h2>
						<ul class="szc-queue-stats">
							<?php foreach ( $board as $b ) : ?>
								<li><?php echo esc_html( $b['name'] ); ?>: <b><?php echo esc_html( szc_fa_digits( $b['calls'] ) ); ?></b></li>
							<?php endforeach; ?>
						</ul>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
